from flask import Flask, json, jsonify
from flask import request
from Pizzaria import Pedido
from playhouse.shortcuts import model_to_dict

app = Flask(__name__)

@app.route('/Pizzaria')
def listar():
    pedidos = list(map(model_to_dict, Pedido.select()))
    response = jsonify({"lista": pedidos})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

app.run(debug=True, port=4999)
